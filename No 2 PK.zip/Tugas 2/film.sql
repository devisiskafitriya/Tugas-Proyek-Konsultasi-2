SELECT film_id, title, language_id
FROM film;
